require("dotenv").config();
const {
  Client,
  GatewayIntentBits,
  SlashCommandBuilder,
  REST,
  Routes,
  EmbedBuilder,
} = require("discord.js");
const http = require("http");
const fs = require("fs");

// ===== STAŁA – LINK ZAPROSZENIA =====
const INVITE_LINK = "https://discord.gg/nCugrcGa5S";

// ===== Pliki =====
const INVITES_FILE = "./invites.json";
const CONFIG_FILE = "./config.json";

let invitesData = {};
try {
  invitesData = JSON.parse(fs.readFileSync(INVITES_FILE, "utf8"));
} catch (err) {
  invitesData = {};
}

let config = {
  thresholds: [],
  allowed: { users: [], roles: [] },
  punishmentRoleId: null,
  welcomeMessages: [
    "Witaj na serwerze 💙 Fani Patiego 🎉. Będziemy robić konkursy z legit check. Pamiętaj o regulaminie. Mamy nadzieję, że Ci się spodoba. Jeśli chcesz zaprosić osoby, zalecamy Ci skopiować reklamę i dopisać, aby ludzie wiedzieli co to jest.",
    "# Serwer 💙 Pati's fans 🎉\n## Dlaczego warto dołączyć?\n**┇📺┇ Kanał reklamowy**\n**┇📖┇ Czytelne zasady**\n**┇🎲 ┇ Kanały 4 fun**\n**┇🎉 ┇ Legitne konkursy**\n**┇🤣┇ Wysyłanie odpowiednich memów**\n**┇🔊┇Kanały głosowe z możliwością AFK**\n**┇📜 ┇Możliwość wysyłania propozycji**\n**┇🟢 ┇Kanały dla Ciebie z dużą możliwością aktywności** \n**┇👍 ┇ Automatyczny system ról za zaproszenia**\n## Dołącz teraz i zapraszaj wszystkich, których chcesz!\nLink: https://discord.gg/nCugrcGa5S"
  ],
  banReasons: {},
  monitoredUsers: [],
  banWarnings: {},
  banLimit: 3
};

try {
  const loaded = JSON.parse(fs.readFileSync(CONFIG_FILE, "utf8"));
  config = { ...config, ...loaded };
  if (!config.thresholds) config.thresholds = [];
  if (!config.allowed) config.allowed = { users: [], roles: [] };
  if (!config.allowed.users) config.allowed.users = [];
  if (!config.allowed.roles) config.allowed.roles = [];
  if (!config.welcomeMessages || !Array.isArray(config.welcomeMessages) || config.welcomeMessages.length < 2) {
    config.welcomeMessages = [
      "Witaj na serwerze 💙 Fani Patiego 🎉. Będziemy robić konkursy z legit check. Pamiętaj o regulaminie. Mamy nadzieję, że Ci się spodoba. Jeśli chcesz zaprosić osoby, zalecamy Ci skopiować reklamę i dopisać, aby ludzie wiedzieli co to jest.",
      "# Serwer 💙 Pati's fans 🎉\n## Co jest fajnego?\n**┇📺┇ Kanał reklamowy**\n**┇📖┇ Czytelne zasady**\n**┇🎲 ┇ Kanały 4 fun**\n**┇🎉 ┇ Legitne konkursy**\n**┇🤣┇ Wysyłanie odpowiednich memów**\n**┇🔊┇Kanały głosowe z możliwością AFK**\n**┇📜 ┇Możliwość wysyłania propozycji**\n**┇🟢 ┇Kanały dla Ciebie z dużą możliwością aktywności** \n**┇👍 ┇ Automatyczny system ról za zaproszenia**\n## Dołącz teraz i zapraszaj wszystkich, których chcesz!\nLink: https://discord.gg/nCugrcGa5S"
    ];
  }
  if (!config.banReasons) config.banReasons = {};
  if (!config.monitoredUsers) config.monitoredUsers = [];
  if (!config.banWarnings) config.banWarnings = {};
  if (!config.banLimit) config.banLimit = 3;
} catch (err) {
  saveConfig();
}

function saveInvites() {
  fs.writeFileSync(INVITES_FILE, JSON.stringify(invitesData, null, 2));
}

function saveConfig() {
  fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
}

// ===== Zmienne środowiskowe =====
const TOKEN = process.env.DISCORD_TOKEN;
const GUILD_ID = process.env.GUILD_ID;
const LOG_CHANNEL_ID = process.env.LOG_CHANNEL_ID;

console.log("🔧 Sprawdzam zmienne środowiskowe...");
console.log(`DISCORD_TOKEN istnieje: ${TOKEN ? "TAK" : "NIE"}`);
console.log(`GUILD_ID istnieje: ${GUILD_ID ? "TAK" : "NIE"}`);
console.log(`LOG_CHANNEL_ID istnieje: ${LOG_CHANNEL_ID ? "TAK" : "NIE"}`);
if (TOKEN) console.log(`🔑 Token (pierwsze 6 znaków): ${TOKEN.substring(0, 6)}...`);

if (!TOKEN || !GUILD_ID) {
  console.error("❌ Brak DISCORD_TOKEN lub GUILD_ID w zmiennych środowiskowych.");
  process.exit(1);
}

// ===== Klient =====
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildInvites,
    GatewayIntentBits.GuildModeration,
  ],
});

// ===== Funkcje pomocnicze =====
async function logToChannel(message) {
  if (!LOG_CHANNEL_ID) return;
  const channel = client.channels.cache.get(LOG_CHANNEL_ID);
  if (!channel) return;
  try {
    await channel.send(message);
  } catch (err) {
    console.error("❌ Błąd wysyłania logu:", err);
  }
}

function hasAdminPermission(interaction) {
  if (!interaction.guild) return false;
  const member = interaction.member;
  if (member.id === interaction.guild.ownerId) return true;
  const memberRoles = member.roles.cache.map(r => r.id);
  if (config.allowed.roles.some(roleId => memberRoles.includes(roleId))) return true;
  if (config.allowed.users.includes(member.id)) return true;
  return false;
}

function extractId(input) {
  if (!input) return null;
  const match = input.match(/<@!?(\d+)>/);
  if (match) return match[1];
  if (/^\d+$/.test(input)) return input;
  return null;
}

async function sendUnbanDM(user, guildName) {
  const message = `Zostałeś odbanowany z serwera ${guildName}. Dołącz z powrotem po więcej zabawy. ${INVITE_LINK}`;
  try {
    await user.send(message);
    console.log(`✅ Wysłano DM o odbanowaniu do ${user.tag}`);
  } catch (err) {
    console.error(`❌ Nie udało się wysłać DM o odbanowaniu do ${user.tag}:`, err.message);
  }
}

async function sendWelcomeDM(member) {
  const msgs = config.welcomeMessages;
  if (!msgs || !Array.isArray(msgs) || msgs.length < 2) return;
  try {
    if (msgs[0]) await member.send(msgs[0]);
    if (msgs[1]) await member.send(msgs[1]);
    console.log(`✅ Wysłano powitania DM do ${member.user.tag}`);
  } catch (err) {
    console.error(`❌ Nie udało się wysłać DM do ${member.user.tag}:`, err.message);
    await logToChannel(`⚠️ Nie udało się wysłać powitań do **${member.user.tag}** (DM wyłączone).`);
  }
}

async function updateInviteRoles(member) {
  const userId = member.id;
  const invites = invitesData[userId] || 0;

  const sorted = [...config.thresholds].sort((a, b) => b.invites - a.invites);
  let targetRoleId = null;
  for (const t of sorted) {
    if (invites >= t.invites) {
      targetRoleId = t.roleId;
      break;
    }
  }

  const roleToThreshold = new Map();
  config.thresholds.forEach(t => roleToThreshold.set(t.roleId, t.invites));

  const allRoleIds = config.thresholds.map(t => t.roleId);
  const currentRoles = member.roles.cache;

  for (const roleId of allRoleIds) {
    const threshold = roleToThreshold.get(roleId);
    if (threshold > invites && currentRoles.has(roleId)) {
      await member.roles.remove(roleId).catch(console.error);
      console.log(`➖ Usunięto rolę ${roleId} (próg ${threshold}) użytkownikowi ${member.user.tag}`);
    }
  }

  if (targetRoleId && !currentRoles.has(targetRoleId)) {
    await member.roles.add(targetRoleId).catch(console.error);
    console.log(`✅ Nadano rolę ${targetRoleId} (${invites} zaproszeń) użytkownikowi ${member.user.tag}`);
    await logToChannel(
      `🎉 **${member.user.tag}** osiągnął **${invites}** zaproszeń → rola <@&${targetRoleId}>.`
    );
  }
}

async function refreshInvites(guild) {
  try {
    const invites = await guild.invites.fetch();
    const current = {};
    invites.forEach(inv => {
      if (inv.inviter) {
        current[inv.inviter.id] = (current[inv.inviter.id] || 0) + inv.uses;
      }
    });
    for (const [id, uses] of Object.entries(current)) {
      invitesData[id] = uses;
    }
    saveInvites();
    console.log(`📥 Zaktualizowano zaproszenia dla ${Object.keys(current).length} użytkowników.`);
    return current;
  } catch (err) {
    console.error("❌ Błąd odświeżania zaproszeń:", err);
    return null;
  }
}

async function handleBanPunishment(ban) {
  const guild = ban.guild;
  const user = ban.user;
  const reason = ban.reason || "";

  if (reason.trim().length > 0) {
    config.banReasons[user.id] = reason;
    saveConfig();
  }

  const punishmentRoleId = config.punishmentRoleId;
  if (!punishmentRoleId) {
    console.log(`ℹ️ Brak ustawionej roli karowej – pomijam karę.`);
    return;
  }

  const role = guild.roles.cache.get(punishmentRoleId);
  if (!role) {
    console.warn(`⚠️ Rola karowa ${punishmentRoleId} nie istnieje – pomijam karę.`);
    await logToChannel(`⚠️ Rola karowa <@&${punishmentRoleId}> nie istnieje – pomijam karę.`);
    return;
  }

  const pattern = /^Brak powodu ~ \d+$/;
  const isPatternMatch = pattern.test(reason.trim());

  if (reason.trim().length > 0 && !isPatternMatch) {
    console.log(`ℹ️ Ban na ${user.tag} ma powód: "${reason}" – brak kary.`);
    await logToChannel(`ℹ️ Ban na **${user.tag}** ma powód: "${reason}" – brak kary.`);
    return;
  }

  console.log(`🔨 Wykryto ban bez powodu lub z wzorcem na ${user.tag}. Powód: "${reason || 'BRAK'}"`);

  try {
    const auditLogs = await guild.fetchAuditLogs({ type: 22, limit: 5 });
    const banEntry = auditLogs.entries.find(entry => entry.target.id === user.id);
    if (!banEntry) {
      console.warn(`⚠️ Nie znaleziono wpisu w audit logu dla bana ${user.tag}`);
      await logToChannel(`⚠️ Nie znaleziono, kto zbanował **${user.tag}** – pomijam karę.`);
      return;
    }

    const executor = banEntry.executor;
    if (!executor) {
      console.warn(`⚠️ Nie ustalono wykonawcy bana dla ${user.tag}`);
      await logToChannel(`⚠️ Nie ustalono wykonawcy bana dla **${user.tag}** – pomijam karę.`);
      return;
    }

    if (!config.monitoredUsers.includes(executor.id)) {
      console.log(`ℹ️ ${executor.tag} nie jest na liście monitorowanych – pomijam karę.`);
      await logToChannel(`ℹ️ **${executor.tag}** nie jest monitorowany – brak kary.`);
      return;
    }

    const member = await guild.members.fetch(executor.id).catch(() => null);
    if (!member) {
      console.warn(`⚠️ Wykonawca ${executor.tag} nie jest już na serwerze.`);
      await logToChannel(`⚠️ **${executor.tag}** nie jest już na serwerze – nie mogę usunąć roli.`);
      return;
    }

    if (!member.roles.cache.has(punishmentRoleId)) {
      console.log(`ℹ️ ${executor.tag} nie ma roli karnej – pomijam.`);
      await logToChannel(`ℹ️ **${executor.tag}** nie ma roli karnej – nic nie usuwam.`);
      return;
    }

    if (!guild.members.me.permissions.has("ManageRoles")) {
      console.error(`❌ Bot nie ma uprawnienia ManageRoles.`);
      await logToChannel(`❌ Bot nie ma uprawnienia do zarządzania rolami.`);
      return;
    }

    if (!config.banWarnings[executor.id]) config.banWarnings[executor.id] = 0;
    config.banWarnings[executor.id] += 1;
    const warnings = config.banWarnings[executor.id];
    const limit = config.banLimit || 3;
    saveConfig();

    console.log(`⚠️ ${executor.tag} otrzymał ostrzeżenie (${warnings}/${limit}) za ban na ${user.tag}.`);
    await logToChannel(`⚠️ **${executor.tag}** otrzymał ostrzeżenie **${warnings}/${limit}** za ban na **${user.tag}** (powód: "${reason || 'BRAK'}").`);

    await member.roles.remove(punishmentRoleId);
    console.log(`🔨 Usunięto rolę ${punishmentRoleId} od ${executor.tag} (ostrzeżenie ${warnings}).`);
    await logToChannel(`🔨 **${executor.tag}** stracił rolę <@&${punishmentRoleId}> (ostrzeżenie ${warnings}/${limit}).`);

    if (warnings >= limit) {
      try {
        await member.roles.set([]);
        console.log(`💥 ${executor.tag} przekroczył limit ostrzeżeń – usunięto wszystkie role.`);
        await logToChannel(`💥 **${executor.tag}** przekroczył limit **${limit}** ostrzeżeń – usunięto wszystkie role.`);
      } catch (err) {
        console.error(`❌ Błąd usuwania ról dla ${executor.tag}:`, err);
        await logToChannel(`❌ Nie udało się usunąć ról dla **${executor.tag}**: ${err.message}`);
      }
    }

    if (!guild.members.me.permissions.has("BanMembers")) {
      console.error(`❌ Bot nie ma uprawnienia BanMembers.`);
      await logToChannel(`❌ Bot nie ma uprawnienia do odbanowywania.`);
      return;
    }

    try {
      await guild.members.unban(user.id, `Automatyczne odbanowanie po karze (ban bez powodu)`);
      console.log(`✅ Odbanowano ${user.tag} po karze.`);
      await logToChannel(`✅ **${user.tag}** został odbanowany automatycznie.`);
      await sendUnbanDM(user, guild.name);
    } catch (unbanErr) {
      console.error(`❌ Błąd odbanowania ${user.tag}:`, unbanErr);
      await logToChannel(`❌ Nie udało się odbanować **${user.tag}**: ${unbanErr.message}`);
    }

  } catch (err) {
    console.error(`❌ Błąd w karze za ban:`, err);
    await logToChannel(`❌ Błąd przetwarzania kary za ban: ${err.message}`);
  }
}

// ===== Eventy =====
client.once("ready", async () => {
  console.log(`✅ Zalogowano jako ${client.user.tag}`);

  const rest = new REST({ version: "10" }).setToken(TOKEN);
  const commands = [
    new SlashCommandBuilder()
      .setName("ustaw-role-za-zaproszenia")
      .setDescription("Zarządzaj progami zaproszeń")
      .addSubcommand(sub => sub
        .setName("dodaj")
        .setDescription("Dodaj próg")
        .addIntegerOption(opt => opt.setName("zaproszenia").setDescription("Liczba zaproszeń").setRequired(true))
        .addRoleOption(opt => opt.setName("rola").setDescription("Rola do nadania").setRequired(true)))
      .addSubcommand(sub => sub
        .setName("usun")
        .setDescription("Usuń próg")
        .addIntegerOption(opt => opt.setName("zaproszenia").setDescription("Liczba zaproszeń").setRequired(true)))
      .addSubcommand(sub => sub.setName("lista").setDescription("Wyświetl listę progów")),
    new SlashCommandBuilder()
      .setName("odswiez-role-za-zaproszenia")
      .setDescription("Odświeża role wszystkich członków na podstawie zaproszeń"),
    new SlashCommandBuilder()
      .setName("ustaw-uprawnienia")
      .setDescription("Zarządzaj uprawnieniami (tylko właściciel)")
      .addSubcommand(sub => sub
        .setName("dodaj")
        .setDescription("Dodaj uprawnienia")
        .addStringOption(opt => opt
          .setName("typ")
          .setDescription("user lub role")
          .setRequired(true)
          .addChoices({ name: "Użytkownik", value: "user" }, { name: "Rola", value: "role" }))
        .addStringOption(opt => opt.setName("id").setDescription("ID użytkownika lub roli").setRequired(true)))
      .addSubcommand(sub => sub
        .setName("usun")
        .setDescription("Usuń uprawnienia")
        .addStringOption(opt => opt
          .setName("typ")
          .setDescription("user lub role")
          .setRequired(true)
          .addChoices({ name: "Użytkownik", value: "user" }, { name: "Rola", value: "role" }))
        .addStringOption(opt => opt.setName("id").setDescription("ID użytkownika lub roli").setRequired(true)))
      .addSubcommand(sub => sub.setName("lista").setDescription("Wyświetl listę uprawnionych")),
    new SlashCommandBuilder()
      .setName("top-invites")
      .setDescription("Wyświetla listę 10 osób z największą liczbą zaproszeń"),
    new SlashCommandBuilder()
      .setName("set-punishment-role")
      .setDescription("Ustaw rolę, która będzie usuwana za nieuzasadnione bany")
      .addRoleOption(opt => opt.setName("rola").setDescription("Rola do usunięcia").setRequired(true)),
    new SlashCommandBuilder()
      .setName("set-welcome-messages")
      .setDescription("Ustaw dwie wiadomości powitalne (pierwsza i druga)")
      .addStringOption(opt => opt.setName("pierwsza").setDescription("Pierwsza wiadomość powitalna").setRequired(true))
      .addStringOption(opt => opt.setName("druga").setDescription("Druga wiadomość powitalna").setRequired(true)),
    new SlashCommandBuilder()
      .setName("show-settings")
      .setDescription("Wyświetla aktualne ustawienia bota"),
    new SlashCommandBuilder()
      .setName("punish-ban")
      .setDescription("Usuwa rolę adminowi i odbanowuje ofiarę (ręczne)")
      .addStringOption(opt => opt.setName("uzytkownik").setDescription("ID lub wzmianka użytkownika (banującego)").setRequired(true))
      .addRoleOption(opt => opt.setName("rola").setDescription("Rola do usunięcia").setRequired(true))
      .addStringOption(opt => opt.setName("ofiara").setDescription("ID lub wzmianka ofiary").setRequired(true))
      .addStringOption(opt => opt.setName("powod").setDescription("Powód do logu").setRequired(false)),
    new SlashCommandBuilder()
      .setName("edit-ban-reason")
      .setDescription("Zmień powód bana dla użytkownika")
      .addStringOption(opt => opt.setName("uzytkownik").setDescription("ID lub wzmianka użytkownika").setRequired(true))
      .addStringOption(opt => opt.setName("nowy-powod").setDescription("Nowy powód bana").setRequired(true)),
    new SlashCommandBuilder()
      .setName("add-monitored")
      .setDescription("Dodaj użytkownika do listy monitorowanych (kara za nieuzasadnione bany)")
      .addUserOption(opt => opt.setName("uzytkownik").setDescription("Użytkownik do monitorowania").setRequired(true)),
    new SlashCommandBuilder()
      .setName("remove-monitored")
      .setDescription("Usuń użytkownika z listy monitorowanych")
      .addUserOption(opt => opt.setName("uzytkownik").setDescription("Użytkownik do usunięcia").setRequired(true)),
    new SlashCommandBuilder()
      .setName("list-monitored")
      .setDescription("Wyświetla listę monitorowanych użytkowników i ich ostrzeżeń"),
    new SlashCommandBuilder()
      .setName("set-ban-limit")
      .setDescription("Ustaw limit ostrzeżeń przed karą (domyślnie 3)")
      .addIntegerOption(opt => opt.setName("limit").setDescription("Liczba ostrzeżeń (1-10)").setRequired(true).setMinValue(1).setMaxValue(10)),
    new SlashCommandBuilder()
      .setName("reset-ban-warnings")
      .setDescription("Resetuj licznik ostrzeżeń dla użytkownika")
      .addUserOption(opt => opt.setName("uzytkownik").setDescription("Użytkownik do resetu").setRequired(true)),
  ];

  try {
    await rest.put(Routes.applicationGuildCommands(client.user.id, GUILD_ID), { body: commands });
    console.log(`✅ Komendy slash zarejestrowane dla serwera ${GUILD_ID}.`);
  } catch (error) {
    console.error("❌ Błąd rejestracji komend:", error);
  }

  const guild = client.guilds.cache.get(GUILD_ID);
  if (guild) await refreshInvites(guild);
});

client.on("guildMemberAdd", async (member) => {
  if (member.guild.id !== GUILD_ID) return;
  console.log(`👤 Nowy członek: ${member.user.tag}`);
  await sendWelcomeDM(member);
  try {
    const invites = await member.guild.invites.fetch();
    const current = {};
    invites.forEach(inv => {
      if (inv.inviter) current[inv.inviter.id] = (current[inv.inviter.id] || 0) + inv.uses;
    });

    let inviterId = null;
    for (const [id, uses] of Object.entries(current)) {
      const old = invitesData[id] || 0;
      if (uses > old) {
        inviterId = id;
        break;
      }
    }

    if (inviterId) {
      invitesData[inviterId] = current[inviterId];
      saveInvites();
      const inviter = await member.guild.members.fetch(inviterId).catch(() => null);
      if (inviter) {
        console.log(`👤 ${inviter.user.tag} zaprosił ${member.user.tag}`);
        await updateInviteRoles(inviter);
      }
    }

    for (const [id, uses] of Object.entries(current)) {
      invitesData[id] = uses;
    }
    saveInvites();
  } catch (err) {
    console.error("❌ Błąd podczas obsługi nowego członka:", err);
  }
});

client.on("guildBanAdd", async (ban) => {
  if (ban.guild.id !== GUILD_ID) return;
  console.log(`🔨 Wykryto ban na ${ban.user.tag} w ${ban.guild.name}. Powód: "${ban.reason || 'BRAK'}"`);
  await handleBanPunishment(ban);
});

client.on("interactionCreate", async (interaction) => {
  if (!interaction.isCommand()) return;

  const { commandName, options, guild } = interaction;

  // ---- KOMENDY MONITOROWANIA ----
  if (commandName === "add-monitored") {
    if (!hasAdminPermission(interaction)) {
      return interaction.reply({ content: "❌ Brak uprawnień.", ephemeral: true });
    }
    const user = options.getUser("uzytkownik");
    if (config.monitoredUsers.includes(user.id)) {
      return interaction.reply({ content: `⚠️ ${user} już jest na liście monitorowanych.`, ephemeral: true });
    }
    config.monitoredUsers.push(user.id);
    saveConfig();
    await interaction.reply({ content: `✅ Dodano ${user} do listy monitorowanych.`, ephemeral: true });
    await logToChannel(`📋 **${interaction.user.tag}** dodał **${user.tag}** do listy monitorowanych.`);
  }

  else if (commandName === "remove-monitored") {
    if (!hasAdminPermission(interaction)) {
      return interaction.reply({ content: "❌ Brak uprawnień.", ephemeral: true });
    }
    const user = options.getUser("uzytkownik");
    const idx = config.monitoredUsers.indexOf(user.id);
    if (idx === -1) {
      return interaction.reply({ content: `⚠️ ${user} nie jest na liście monitorowanych.`, ephemeral: true });
    }
    config.monitoredUsers.splice(idx, 1);
    saveConfig();
    await interaction.reply({ content: `✅ Usunięto ${user} z listy monitorowanych.`, ephemeral: true });
    await logToChannel(`🗑️ **${interaction.user.tag}** usunął **${user.tag}** z listy monitorowanych.`);
  }

  else if (commandName === "list-monitored") {
    if (!hasAdminPermission(interaction)) {
      return interaction.reply({ content: "❌ Brak uprawnień.", ephemeral: true });
    }
    if (config.monitoredUsers.length === 0) {
      return interaction.reply({ content: "📋 Brak monitorowanych użytkowników.", ephemeral: true });
    }
    let msg = "**👀 Lista monitorowanych użytkowników:**\n";
    for (const id of config.monitoredUsers) {
      const member = await guild.members.fetch(id).catch(() => null);
      const name = member ? member.user.tag : `Nieznany (${id})`;
      const warnings = config.banWarnings[id] || 0;
      msg += `- ${name} – **${warnings}** ostrzeżeń\n`;
    }
    await interaction.reply({ content: msg, ephemeral: true });
  }

  else if (commandName === "set-ban-limit") {
    if (!hasAdminPermission(interaction)) {
      return interaction.reply({ content: "❌ Brak uprawnień.", ephemeral: true });
    }
    const limit = options.getInteger("limit");
    config.banLimit = limit;
    saveConfig();
    await interaction.reply({ content: `✅ Ustawiono limit ostrzeżeń na **${limit}**.`, ephemeral: true });
    await logToChannel(`🔧 **${interaction.user.tag}** ustawił limit ostrzeżeń na **${limit}**.`);
  }

  else if (commandName === "reset-ban-warnings") {
    if (!hasAdminPermission(interaction)) {
      return interaction.reply({ content: "❌ Brak uprawnień.", ephemeral: true });
    }
    const user = options.getUser("uzytkownik");
    if (!config.banWarnings[user.id]) {
      return interaction.reply({ content: `⚠️ ${user} nie ma żadnych ostrzeżeń.`, ephemeral: true });
    }
    delete config.banWarnings[user.id];
    saveConfig();
    await interaction.reply({ content: `✅ Zresetowano ostrzeżenia dla ${user}.`, ephemeral: true });
    await logToChannel(`🔄 **${interaction.user.tag}** zresetował ostrzeżenia dla **${user.tag}**.`);
  }

  // ---- RĘCZNA KARA ----
  else if (commandName === "punish-ban") {
    if (!hasAdminPermission(interaction)) {
      return interaction.reply({ content: "❌ Brak uprawnień.", ephemeral: true });
    }

    const userInput = options.getString("uzytkownik");
    const role = options.getRole("rola");
    const targetInput = options.getString("ofiara");
    const reason = options.getString("powod") || "Ręczne wykonanie kary";

    const userId = extractId(userInput);
    const targetId = extractId(targetInput);

    if (!userId || !targetId) {
      return interaction.reply({ content: "❌ Nieprawidłowy identyfikator użytkownika.", ephemeral: true });
    }

    try {
      const member = await guild.members.fetch(userId).catch(() => null);
      if (!member) {
        return interaction.reply({ content: `❌ Użytkownik <@${userId}> nie jest na serwerze.`, ephemeral: true });
      }
      if (!member.roles.cache.has(role.id)) {
        return interaction.reply({ content: `❌ <@${userId}> nie ma roli ${role.name}.`, ephemeral: true });
      }
      if (!guild.members.me.permissions.has("ManageRoles")) {
        return interaction.reply({ content: `❌ Bot nie ma uprawnienia do zarządzania rolami.`, ephemeral: true });
      }
      await member.roles.remove(role.id);
      console.log(`🔨 Ręcznie usunięto rolę ${role.id} od ${member.user.tag} (powód: ${reason})`);
      await logToChannel(`🔨 **${interaction.user.tag}** ręcznie usunął rolę ${role} od **${member.user.tag}** (powód: ${reason}).`);

      if (!guild.members.me.permissions.has("BanMembers")) {
        await interaction.reply({ content: `⚠️ Usunięto rolę, ale bot nie ma uprawnienia do odbanowywania.`, ephemeral: true });
        return;
      }

      try {
        await guild.members.unban(targetId, `Ręczne odbanowanie przez ${interaction.user.tag}: ${reason}`);
        console.log(`✅ Ręcznie odbanowano <@${targetId}>`);
        await logToChannel(`✅ **<@${targetId}>** został odbanowany ręcznie przez ${interaction.user.tag}.`);
        await interaction.reply({ content: `✅ Usunięto rolę ${role} od <@${userId}> i odbanowano <@${targetId}>.`, ephemeral: true });

        const targetUser = await client.users.fetch(targetId).catch(() => null);
        if (targetUser) await sendUnbanDM(targetUser, guild.name);
      } catch (unbanErr) {
        console.error(`❌ Błąd odbanowania <@${targetId}>:`, unbanErr);
        await interaction.reply({ content: `⚠️ Usunięto rolę, ale nie udało się odbanować <@${targetId}>: ${unbanErr.message}`, ephemeral: true });
      }
    } catch (err) {
      console.error(`❌ Błąd w komendzie punish-ban:`, err);
      await interaction.reply({ content: `❌ Wystąpił błąd: ${err.message}`, ephemeral: true });
    }
  }

  // ---- EDYCJA POWODU ----
  else if (commandName === "edit-ban-reason") {
    if (!hasAdminPermission(interaction)) {
      return interaction.reply({ content: "❌ Brak uprawnień.", ephemeral: true });
    }
    const userInput = options.getString("uzytkownik");
    const newReason = options.getString("nowy-powod");
    const userId = extractId(userInput);
    if (!userId) {
      return interaction.reply({ content: "❌ Nieprawidłowy identyfikator użytkownika.", ephemeral: true });
    }
    if (!config.banReasons[userId]) {
      return interaction.reply({ content: `❌ Nie znaleziono powodu bana dla <@${userId}>.`, ephemeral: true });
    }
    config.banReasons[userId] = newReason;
    saveConfig();
    await interaction.reply({ content: `✅ Zaktualizowano powód bana dla <@${userId}> na: "${newReason}".`, ephemeral: true });
    await logToChannel(`📝 **${interaction.user.tag}** zmienił powód bana dla <@${userId}> na: "${newReason}".`);
  }

  // ---- USTAW ROLĘ KAROWĄ ----
  else if (commandName === "set-punishment-role") {
    if (!hasAdminPermission(interaction)) {
      return interaction.reply({ content: "❌ Brak uprawnień.", ephemeral: true });
    }
    const role = options.getRole("rola");
    config.punishmentRoleId = role.id;
    saveConfig();
    await interaction.reply({ content: `✅ Ustawiono rolę karową na ${role}.`, ephemeral: true });
    await logToChannel(`🔧 **${interaction.user.tag}** ustawił rolę karową na ${role}.`);
  }

  // ---- USTAW WIADOMOŚCI POWITALNE ----
  else if (commandName === "set-welcome-messages") {
    if (!hasAdminPermission(interaction)) {
      return interaction.reply({ content: "❌ Brak uprawnień.", ephemeral: true });
    }
    const first = options.getString("pierwsza");
    const second = options.getString("druga");
    config.welcomeMessages = [first, second];
    saveConfig();
    await interaction.reply({ content: `✅ Ustawiono nowe wiadomości powitalne.`, ephemeral: true });
    await logToChannel(`🔧 **${interaction.user.tag}** zaktualizował wiadomości powitalne.`);
  }

  // ---- POKAŻ USTAWIENIA ----
  else if (commandName === "show-settings") {
    if (!hasAdminPermission(interaction)) {
      return interaction.reply({ content: "❌ Brak uprawnień.", ephemeral: true });
    }
    const roleId = config.punishmentRoleId;
    const role = roleId ? guild.roles.cache.get(roleId) : null;
    const roleName = role ? role.toString() : (roleId ? `Nieznana rola (${roleId})` : "❌ Nie ustawiono");
    const msgs = config.welcomeMessages || ["(domyślna)", "(domyślna)"];
    const limit = config.banLimit || 3;
    const monitored = config.monitoredUsers.length;
    let msg = `**🔨 Rola karowa:** ${roleName}\n**📨 Wiadomości powitalne:**\n1. ${msgs[0] || '(brak)'}\n2. ${msgs[1] || '(brak)'}\n**📊 Limit ostrzeżeń:** ${limit}\n**👀 Monitorowani użytkownicy:** ${monitored}`;
    await interaction.reply({ content: msg, ephemeral: true });
  }

  // ---- ZARZĄDZANIE PROGAMI ZAPROSZEŃ ----
  else if (commandName === "ustaw-role-za-zaproszenia") {
    if (!hasAdminPermission(interaction)) {
      return interaction.reply({ content: "❌ Brak uprawnień.", ephemeral: true });
    }
    const sub = options.getSubcommand();
    if (sub === "dodaj") {
      const invites = options.getInteger("zaproszenia");
      const role = options.getRole("rola");
      if (invites < 1) return interaction.reply({ content: "❌ Liczba musi być dodatnia.", ephemeral: true });
      if (config.thresholds.some(t => t.invites === invites)) {
        return interaction.reply({ content: `❌ Próg ${invites} już istnieje.`, ephemeral: true });
      }
      config.thresholds.push({ invites, roleId: role.id });
      config.thresholds.sort((a, b) => a.invites - b.invites);
      saveConfig();
      await interaction.reply({ content: `✅ Dodano próg: **${invites}** zaproszeń → ${role}`, ephemeral: true });
      await logToChannel(`✅ **${interaction.user.tag}** dodał próg: **${invites}** zaproszeń → ${role}.`);
    } else if (sub === "usun") {
      const invites = options.getInteger("zaproszenia");
      const idx = config.thresholds.findIndex(t => t.invites === invites);
      if (idx === -1) return interaction.reply({ content: `❌ Nie znaleziono progu ${invites}.`, ephemeral: true });
      config.thresholds.splice(idx, 1);
      saveConfig();
      await interaction.reply({ content: `✅ Usunięto próg ${invites} zaproszeń.`, ephemeral: true });
      await logToChannel(`🗑️ **${interaction.user.tag}** usunął próg **${invites}** zaproszeń.`);
    } else if (sub === "lista") {
      if (config.thresholds.length === 0) return interaction.reply({ content: "📋 Brak progów.", ephemeral: true });
      const list = config.thresholds.map(t => `**${t.invites}** → <@&${t.roleId}>`).join("\n");
      await interaction.reply({ content: `📋 **Lista progów:**\n${list}`, ephemeral: true });
    }
  }

  // ---- ODŚWIEŻ ROLE ----
  else if (commandName === "odswiez-role-za-zaproszenia") {
    if (!hasAdminPermission(interaction)) {
      return interaction.reply({ content: "❌ Brak uprawnień.", ephemeral: true });
    }
    await interaction.reply({ content: "🔄 Odświeżam...", ephemeral: true });
    await refreshInvites(guild);
    const members = await guild.members.fetch();
    for (const [, member] of members) {
      await updateInviteRoles(member);
    }
    await interaction.editReply({ content: "✅ Odświeżanie zakończone." });
  }

  // ---- ZARZĄDZANIE UPRAWNIENIAMI ----
  else if (commandName === "ustaw-uprawnienia") {
    if (interaction.user.id !== interaction.guild.ownerId) {
      return interaction.reply({ content: "❌ Tylko właściciel serwera.", ephemeral: true });
    }
    const sub = options.getSubcommand();
    const typ = options.getString("typ");
    const id = options.getString("id");

    if (sub === "dodaj") {
      if (typ === "user") {
        if (!config.allowed.users.includes(id)) {
          config.allowed.users.push(id);
          saveConfig();
          await interaction.reply({ content: `✅ Dodano <@${id}> do uprawnionych.`, ephemeral: true });
          await logToChannel(`✅ **${interaction.user.tag}** dodał uprawnienia dla <@${id}>.`);
        } else {
          await interaction.reply({ content: `⚠️ <@${id}> już jest uprawniony.`, ephemeral: true });
        }
      } else {
        if (!config.allowed.roles.includes(id)) {
          config.allowed.roles.push(id);
          saveConfig();
          await interaction.reply({ content: `✅ Dodano rolę <@&${id}> do uprawnionych.`, ephemeral: true });
          await logToChannel(`✅ **${interaction.user.tag}** dodał uprawnienia dla roli <@&${id}>.`);
        } else {
          await interaction.reply({ content: `⚠️ Rola <@&${id}> już jest uprawniona.`, ephemeral: true });
        }
      }
    } else if (sub === "usun") {
      if (typ === "user") {
        const idx = config.allowed.users.indexOf(id);
        if (idx !== -1) {
          config.allowed.users.splice(idx, 1);
          saveConfig();
          await interaction.reply({ content: `✅ Usunięto <@${id}> z uprawnionych.`, ephemeral: true });
          await logToChannel(`🗑️ **${interaction.user.tag}** usunął uprawnienia dla <@${id}>.`);
        } else {
          await interaction.reply({ content: `⚠️ <@${id}> nie jest uprawniony.`, ephemeral: true });
        }
      } else {
        const idx = config.allowed.roles.indexOf(id);
        if (idx !== -1) {
          config.allowed.roles.splice(idx, 1);
          saveConfig();
          await interaction.reply({ content: `✅ Usunięto rolę <@&${id}> z uprawnionych.`, ephemeral: true });
          await logToChannel(`🗑️ **${interaction.user.tag}** usunął uprawnienia dla roli <@&${id}>.`);
        } else {
          await interaction.reply({ content: `⚠️ Rola <@&${id}> nie jest uprawniona.`, ephemeral: true });
        }
      }
    } else if (sub === "lista") {
      let msg = "**Uprawnieni użytkownicy:**\n";
      msg += config.allowed.users.length ? config.allowed.users.map(u => `<@${u}>`).join(", ") : "Brak";
      msg += "\n\n**Uprawnione role:**\n";
      msg += config.allowed.roles.length ? config.allowed.roles.map(r => `<@&${r}>`).join(", ") : "Brak";
      await interaction.reply({ content: msg, ephemeral: true });
    }
  }

  // ---- TOP INVITES ----
  else if (commandName === "top-invites") {
    await guild.members.fetch();

    const invitesList = Object.entries(invitesData)
      .map(([userId, count]) => ({ userId, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 10);

    if (invitesList.length === 0) {
      return interaction.reply({ content: "📊 Brak danych o zaproszeniach.", ephemeral: true });
    }

    const embed = new EmbedBuilder()
      .setTitle("🏆 Top 10 zapraszających")
      .setColor(0x00AE86)
      .setTimestamp()
      .setFooter({ text: "Invite Role Bot", iconURL: client.user.displayAvatarURL() });

    let description = "";
    let position = 1;
    for (const item of invitesList) {
      const member = guild.members.cache.get(item.userId);
      const name = member ? member.user.tag : `Nieznany użytkownik (${item.userId})`;
      description += `**${position}.** ${name} – **${item.count}** zaproszeń\n`;
      position++;
    }
    embed.setDescription(description);
    await interaction.reply({ embeds: [embed] });
  }
});

// ===== Serwer HTTP =====
const server = http.createServer((req, res) => {
  res.writeHead(200, { "Content-Type": "text/html" });
  res.end("<h1>✅ Bot działa 24/7!</h1>");
});

const PORT = Number(process.env.PORT) || 3000;

function startServer(port) {
  if (isNaN(port)) {
    console.error("❌ Nieprawidłowy port:", port);
    return;
  }
  server.listen(port, () => console.log(`🌐 Serwer HTTP na porcie ${port}`));
  server.on("error", (err) => {
    if (err.code === "EADDRINUSE") {
      console.log(`⚠️ Port ${port} zajęty, próbuję port ${port + 1}`);
      startServer(port + 1);
    } else {
      console.error("❌ Błąd serwera:", err);
    }
  });
}
startServer(PORT);

client.login(TOKEN);